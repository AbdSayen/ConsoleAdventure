﻿namespace ConsoleAdventure.Generate.Structures
{
    public abstract class Structure
    {
        public string name {  get;  set; }
    }
}

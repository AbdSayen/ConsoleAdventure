﻿namespace ConsoleAdventure
{
    public enum ItemType
    {
    }
}

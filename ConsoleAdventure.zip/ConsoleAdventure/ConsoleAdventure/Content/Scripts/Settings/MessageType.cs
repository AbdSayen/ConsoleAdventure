﻿namespace ConsoleAdventure.Settings
{
    public enum MessageType { 
        info,
        error,
        warning
    }
}
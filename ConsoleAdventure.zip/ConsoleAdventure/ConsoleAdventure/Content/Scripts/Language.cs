﻿namespace ConsoleAdventure
{
    public enum Language
    {
        english,
        russian,
    }
}